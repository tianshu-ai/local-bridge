// Tianshu Local Bridge — macOS menu-bar app.
//
// A thin GUI wrapper around the `tsbridge` CLI: lives only in the menu
// bar (LSUIElement), lets you set the server URL / token / browser
// engine / headless, and Start/Stop the bridge. It spawns `tsbridge`
// with the chosen flags and shows connection status. Config persists to
// ~/.tianshu-bridge/config.json.
//
// Built on demand by install-app.sh via `swiftc` — no external deps.

import AppKit
import Foundation

// ─── config ─────────────────────────────────────────────────────────

struct Config: Codable {
    var server: String = "ws://localhost:3110/ws"
    var token: String = ""
    var browser: Bool = true           // expose browser tools (on by default)
    var engine: String = "own"        // "own" | "stealth" (browser sub-option)
    var headless: Bool = false         // browser sub-option
    var shell: Bool = false            // expose exec + file sync (opt-in)
    var device: String = ""            // empty → hostname

    static var path: URL {
        let dir = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent(".tianshu-bridge", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("config.json")
    }

    static func load() -> Config {
        guard let data = try? Data(contentsOf: path),
              let cfg = try? JSONDecoder().decode(Config.self, from: data) else {
            return Config()
        }
        return cfg
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) {
            try? data.write(to: Config.path)
        }
    }
}

// ─── locating tsbridge / node ────────────────────────────────────────

// GUI apps don't inherit the shell PATH, and tsbridge often lives under
// a Node version manager (nvm/fnm). Resolve a usable command + PATH.
func resolveTsbridge() -> (cmd: String, env: [String: String])? {
    let fm = FileManager.default
    let home = fm.homeDirectoryForCurrentUser.path
    var candidates: [String] = [
        "/usr/local/bin/tsbridge",
        "/opt/homebrew/bin/tsbridge",
    ]
    // nvm: newest version dir that has tsbridge
    let nvm = "\(home)/.nvm/versions/node"
    if let vers = try? fm.contentsOfDirectory(atPath: nvm) {
        for v in vers.sorted(by: >) {
            candidates.append("\(nvm)/\(v)/bin/tsbridge")
        }
    }
    for c in candidates where fm.isExecutableFile(atPath: c) {
        // Prepend the bin dir to PATH so the spawned tsbridge finds
        // `node` and `npx` (needed for @playwright/mcp / cloakbrowser).
        let bin = (c as NSString).deletingLastPathComponent
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "\(bin):/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin"
        // GUI-launched processes can start with an empty/missing HOME;
        // @playwright/mcp & cloakbrowser use it for their output dir
        // (else they try to mkdir /.playwright-mcp and crash). Force it.
        if (env["HOME"] ?? "").isEmpty { env["HOME"] = NSHomeDirectory() }
        return (c, env)
    }
    return nil
}

// ─── the bridge process ──────────────────────────────────────────────

final class Bridge {
    private var proc: Process?
    var isRunning: Bool { proc?.isRunning ?? false }
    var onStateChange: (() -> Void)?

    func start(_ cfg: Config) {
        stop()
        guard let (cmd, env) = resolveTsbridge() else {
            notify("tsbridge not found", "Install it: npm i -g @tianshu-ai/local-bridge")
            return
        }
        var args = ["--server", cfg.server]
        if !cfg.token.isEmpty { args += ["--token", cfg.token] }
        if cfg.browser {
            if cfg.engine == "stealth" { args += ["--browser-engine", "stealth"] }
            if cfg.headless { args += ["--headless"] }
        } else {
            args += ["--no-browser"]
        }
        if cfg.shell { args += ["--shell"] }
        if !cfg.device.isEmpty { args += ["--device", cfg.device] }

        let p = Process()
        p.executableURL = URL(fileURLWithPath: cmd)
        p.arguments = args
        p.environment = env
        // Log to ~/.tianshu-bridge/bridge.log for troubleshooting.
        let logURL = Config.path.deletingLastPathComponent().appendingPathComponent("bridge.log")
        FileManager.default.createFile(atPath: logURL.path, contents: nil)
        if let fh = try? FileHandle(forWritingTo: logURL) {
            p.standardOutput = fh
            p.standardError = fh
        }
        p.terminationHandler = { [weak self] _ in
            DispatchQueue.main.async { self?.onStateChange?() }
        }
        do {
            try p.run()
            proc = p
        } catch {
            notify("Failed to start bridge", error.localizedDescription)
        }
        onStateChange?()
    }

    func stop() {
        if let p = proc, p.isRunning { p.terminate() }
        proc = nil
    }

    private func notify(_ title: String, _ body: String) {
        let a = NSAlert()
        a.messageText = title
        a.informativeText = body
        a.runModal()
    }
}

// ─── menu-bar controller ─────────────────────────────────────────────

final class AppController: NSObject, NSApplicationDelegate {
    // Created in applicationDidFinishLaunching (not at init) so the app
    // is fully up before we claim a status-bar slot.
    var statusItem: NSStatusItem!
    let bridge = Bridge()
    var cfg = Config.load()
    var configWindow: NSWindow?

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        updateIcon()
        bridge.onStateChange = { [weak self] in
            self?.updateIcon()
            self?.rebuildMenu()
        }
        rebuildMenu()
    }

    func updateIcon() {
        guard let btn = statusItem.button else { return }
        let on = bridge.isRunning
        let name = on ? "bolt.horizontal.circle.fill" : "bolt.horizontal.circle"
        if let img = NSImage(systemSymbolName: name, accessibilityDescription: "Tianshu Bridge") {
            img.isTemplate = true
            btn.image = img
            btn.title = ""
        } else {
            // SF Symbol unavailable → always-visible text fallback.
            btn.image = nil
            btn.title = on ? "⚡●" : "⚡"
        }
        btn.toolTip = on ? "Tianshu Bridge: connected" : "Tianshu Bridge: stopped"
    }

    func rebuildMenu() {
        let menu = NSMenu()
        let status = bridge.isRunning ? "● Connected" : "○ Stopped"
        let statusMI = NSMenuItem(title: status, action: nil, keyEquivalent: "")
        statusMI.isEnabled = false
        menu.addItem(statusMI)
        menu.addItem(NSMenuItem(title: "Server: \(cfg.server)", action: nil, keyEquivalent: ""))
        let eng = cfg.engine == "stealth" ? "stealth" : "own"
        let browserDesc = cfg.browser ? "\(eng)\(cfg.headless ? " (headless)" : "")" : "off"
        menu.addItem(NSMenuItem(title: "Browser: \(browserDesc)", action: nil, keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Shell: \(cfg.shell ? "on" : "off")", action: nil, keyEquivalent: ""))
        menu.addItem(.separator())

        if bridge.isRunning {
            menu.addItem(withTitle: "Stop", action: #selector(stop), keyEquivalent: "s").target = self
        } else {
            menu.addItem(withTitle: "Start", action: #selector(start), keyEquivalent: "s").target = self
        }
        menu.addItem(withTitle: "Settings…", action: #selector(openSettings), keyEquivalent: ",").target = self
        menu.addItem(withTitle: "Open Log", action: #selector(openLog), keyEquivalent: "").target = self
        menu.addItem(.separator())
        menu.addItem(withTitle: "Quit", action: #selector(quit), keyEquivalent: "q").target = self
        statusItem.menu = menu
    }

    @objc func start() { bridge.start(cfg) }
    @objc func stop() { bridge.stop(); updateIcon(); rebuildMenu() }
    @objc func openLog() {
        let log = Config.path.deletingLastPathComponent().appendingPathComponent("bridge.log")
        NSWorkspace.shared.open(log)
    }
    @objc func quit() { bridge.stop(); NSApp.terminate(nil) }

    // ── settings window (simple form) ──
    @objc func openSettings() {
        if configWindow == nil {
            let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 380, height: 300),
                             styleMask: [.titled, .closable], backing: .buffered, defer: false)
            w.title = "Tianshu Bridge Settings"
            w.center()
            w.contentView = makeSettingsView()
            w.isReleasedWhenClosed = false
            configWindow = w
        }
        NSApp.activate(ignoringOtherApps: true)
        configWindow?.makeKeyAndOrderFront(nil)
    }

    private var serverField: NSTextField!
    private var tokenField: NSTextField!
    private var browserCheck: NSButton!
    private var enginePopup: NSPopUpButton!
    private var headlessCheck: NSButton!
    private var shellCheck: NSButton!

    private func makeSettingsView() -> NSView {
        let v = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 300))
        func label(_ s: String, _ y: CGFloat) -> NSTextField {
            let l = NSTextField(labelWithString: s); l.frame = NSRect(x: 16, y: y, width: 90, height: 20); return l
        }
        // Paste-config row: grab the config string copied from the
        // tianshu Local Bridge panel and fill every field at once.
        let paste = NSButton(title: "Paste from tianshu", target: self, action: #selector(pasteConfig))
        paste.frame = NSRect(x: 16, y: 258, width: 200, height: 28)
        paste.bezelStyle = .rounded
        v.addSubview(paste)
        let hint = NSTextField(labelWithString: "(copies server + token + browser + shell settings)")
        hint.frame = NSRect(x: 16, y: 238, width: 348, height: 16)
        hint.font = NSFont.systemFont(ofSize: 10)
        hint.textColor = .secondaryLabelColor
        v.addSubview(hint)

        v.addSubview(label("Server", 210))
        serverField = NSTextField(frame: NSRect(x: 110, y: 208, width: 250, height: 24))
        serverField.stringValue = cfg.server; v.addSubview(serverField)

        v.addSubview(label("Token", 172))
        tokenField = NSTextField(frame: NSRect(x: 110, y: 170, width: 250, height: 24))
        tokenField.stringValue = cfg.token; v.addSubview(tokenField)

        // ── Capabilities (Browser + Shell are sibling optional tools) ──
        let capLabel = NSTextField(labelWithString: "Capabilities")
        capLabel.frame = NSRect(x: 16, y: 138, width: 200, height: 18)
        capLabel.font = NSFont.boldSystemFont(ofSize: 12)
        v.addSubview(capLabel)

        // Browser (top-level toggle) + its sub-options (engine, headless).
        browserCheck = NSButton(checkboxWithTitle: "Browser (control a local browser)",
                                target: self, action: #selector(toggleBrowserOptions))
        browserCheck.frame = NSRect(x: 24, y: 116, width: 300, height: 20)
        browserCheck.state = cfg.browser ? .on : .off
        v.addSubview(browserCheck)

        enginePopup = NSPopUpButton(frame: NSRect(x: 44, y: 88, width: 250, height: 26))
        enginePopup.addItems(withTitles: ["own (your Chrome)", "stealth (CloakBrowser)"])
        enginePopup.selectItem(at: cfg.engine == "stealth" ? 1 : 0)
        v.addSubview(enginePopup)

        headlessCheck = NSButton(checkboxWithTitle: "Headless (no window)", target: nil, action: nil)
        headlessCheck.frame = NSRect(x: 44, y: 66, width: 250, height: 20)
        headlessCheck.state = cfg.headless ? .on : .off
        v.addSubview(headlessCheck)

        // Shell (sibling top-level toggle).
        shellCheck = NSButton(checkboxWithTitle: "Shell (run commands + sync files)", target: nil, action: nil)
        shellCheck.frame = NSRect(x: 24, y: 40, width: 300, height: 20)
        shellCheck.state = cfg.shell ? .on : .off
        shellCheck.toolTip = "Exposes exec + file sync on your machine, jailed to ~/.tianshu_shell. Off by default; enable only for a server you trust."
        v.addSubview(shellCheck)

        // Grey out browser sub-options when browser is off.
        updateBrowserOptionsEnabled()

        let save = NSButton(title: "Save & Restart", target: self, action: #selector(saveSettings))
        save.frame = NSRect(x: 200, y: 8, width: 160, height: 30)
        save.bezelStyle = .rounded
        v.addSubview(save)
        return v
    }

    @objc func saveSettings() {
        cfg.server = serverField.stringValue.trimmingCharacters(in: .whitespaces)
        cfg.token = tokenField.stringValue.trimmingCharacters(in: .whitespaces)
        cfg.engine = enginePopup.indexOfSelectedItem == 1 ? "stealth" : "own"
        cfg.browser = browserCheck.state == .on
        cfg.headless = headlessCheck.state == .on
        cfg.shell = shellCheck.state == .on
        cfg.save()
        configWindow?.close()
        rebuildMenu()
        if bridge.isRunning { bridge.start(cfg) } // restart with new config
    }

    // Parse the config string copied from the tianshu panel and fill the
    // form. Accepts a `tsbridge://configure?server=…&token=…&engine=…&
    // headless=…` URL, or a bare query string of the same params.
    @objc func pasteConfig() {
        let raw = (NSPasteboard.general.string(forType: .string) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return alert("Clipboard is empty", "Copy the config from the tianshu Local Bridge panel first.") }
        // Extract the query part whether it's a full URL or bare query.
        var query = raw
        if let q = raw.range(of: "?") { query = String(raw[raw.index(after: q.lowerBound)...]) }
        var params: [String: String] = [:]
        for pair in query.split(separator: "&") {
            let kv = pair.split(separator: "=", maxSplits: 1).map(String.init)
            if kv.count == 2 {
                params[kv[0]] = kv[1].removingPercentEncoding ?? kv[1]
            }
        }
        guard let server = params["server"], !server.isEmpty else {
            return alert("Couldn't read config", "Expected a tsbridge://configure?server=… string copied from the tianshu panel.")
        }
        serverField.stringValue = server
        if let t = params["token"] { tokenField.stringValue = t }
        if let e = params["engine"] { enginePopup.selectItem(at: e == "stealth" ? 1 : 0) }
        if let h = params["headless"] { headlessCheck.state = (h == "1" || h == "true") ? .on : .off }
        if let s = params["shell"] { shellCheck.state = (s == "1" || s == "true") ? .on : .off }
        if let b = params["browser"] { browserCheck.state = (b == "1" || b == "true") ? .on : .off }
        updateBrowserOptionsEnabled()
    }

    // Enable/disable the browser sub-options (engine + headless) to
    // reflect the top-level Browser toggle — they're meaningless when
    // browser is off.
    @objc func toggleBrowserOptions() { updateBrowserOptionsEnabled() }
    private func updateBrowserOptionsEnabled() {
        let on = browserCheck?.state == .on
        enginePopup?.isEnabled = on
        headlessCheck?.isEnabled = on
    }

    private func alert(_ title: String, _ body: String) {
        let a = NSAlert(); a.messageText = title; a.informativeText = body; a.runModal()
    }
}

// ─── main ────────────────────────────────────────────────────────────

let app = NSApplication.shared
app.setActivationPolicy(.accessory) // menu-bar only, no Dock icon
let controller = AppController()
app.delegate = controller
app.run()
